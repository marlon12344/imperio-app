# Mobile - React Native Setup (Android)
Requisitos locais:
- Node.js (>=16), npm ou yarn
- Java JDK 11+
- Android Studio / Android SDK (cmdline-tools)
- React Native CLI

Passos básicos para rodar em desenvolvimento:
1. cd mobile
2. npm install
3. npx react-native run-android
