# Backend - Node.js Setup
1. cd backend
2. npm install
3. cp .env.example .env  (preencher variáveis)
4. npm start
