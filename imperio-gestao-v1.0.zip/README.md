# Império Gestão - Scaffold (v1.0)
Conteúdo deste pacote:
- mobile/ (React Native scaffold pronto para desenvolvimento Android)
- backend/ (Node.js + Express scaffold)
- openapi.yaml (spec da API)
- schema.sql (DB schema)
- .github/workflows/android-build.yml (CI para gerar APK)
- LICENSE (MIT)

Siga as instruções em MOBILE_SETUP.md e BACKEND_SETUP.md para rodar localmente.
